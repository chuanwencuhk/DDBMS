#ifndef MYLOG_H_
#define MYLOG_H_

#include <iostream>

using std::cout;
using std::endl;


#endif