#include <iostream>
#include "rpc/server.h"
#include <string>
#include <fstream>
#include "local_sql.h"
#include "mylog.h"

using std::string;
using std::ifstream;
using std::cout;
using std::endl;

void startServer(); 
